# ChangeSnap — projet Android

Cette première version fournit :
- conversion entre plusieurs devises ;
- sélection d'une photo/image pour lire un montant avec ML Kit ;
- scan OCR continu avec la caméra arrière ;
- choix manuel des devises source et cible ;
- cache local des taux et **maximum une tentative de mise à jour par jour** ;
- conversion hors ligne avec le dernier cache disponible.

## Important
C'est un projet source, pas encore un APK vérifié sur un téléphone. L'APK debug est généré par GitHub Actions. Le scanner OCR ne garantit pas une lecture parfaite : il faut toujours vérifier le montant et choisir la bonne devise. Les taux Frankfurter sont des taux de référence journaliers et non des cours de change instantanés.

## Obtenir l'APK depuis un téléphone Android uniquement

1. Crée un compte sur GitHub si tu n'en as pas.
2. Dans GitHub, crée un dépôt vide nommé `ChangeSnap`.
3. Téléverse le contenu de cette archive dans le dépôt en conservant les dossiers et fichiers. Le plus simple est d'extraire le ZIP sur un appareil qui le permet, puis d'utiliser le site GitHub en mode navigateur. Si le téléversement de dossiers est difficile sur mobile, dis-le : on fera la méthode la plus simple possible étape par étape.
4. Une fois les fichiers présents, ouvre l'onglet **Actions** du dépôt.
5. Ouvre le workflow **Build ChangeSnap APK**, puis **Run workflow** si le build ne démarre pas automatiquement.
6. Attends que le build soit terminé avec une coche verte.
7. Ouvre le build terminé, descends à **Artifacts**, puis télécharge `ChangeSnap-debug-apk`.
8. Décompresse l'archive téléchargée et ouvre `app-debug.apk`. Android peut demander d'autoriser l'installation depuis cette source.

## Règle de mise à jour quotidienne
L'application mémorise les taux localement. Elle ne contacte le service que si aucun taux n'a encore été enregistré, ou si la date locale a changé depuis la dernière tentative. Appuyer plusieurs fois sur « Vérifier les taux » le même jour ne provoque donc pas de nouvelles requêtes. Si le téléphone est hors ligne, l'application garde les taux déjà enregistrés.

## Limites de cette version
- APK de débogage non signé pour publication sur le Play Store.
- Pas de conversion automatique de devise à partir du texte OCR : la devise doit être choisie/confirmée dans l'écran.
- Reconnaissance OCR sensible à la netteté, à l'angle et aux polices ; le montant détecté doit être contrôlé.
- Le projet n'a pas été compilé ni testé sur appareil dans cet environnement.
