package com.changesnap.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToLong

private val currencies = listOf(
    "JPY", "EUR", "USD", "GBP", "CAD", "AUD", "CHF", "CNY", "KRW", "TWD",
    "THB", "SGD", "HKD", "NZD", "INR", "IDR", "MYR", "PHP", "VND", "SEK",
    "NOK", "DKK", "PLN", "CZK", "HUF", "TRY", "MXN", "BRL", "ZAR"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChangeSnapScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChangeSnapScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var amountText by remember { mutableStateOf("1000") }
    var fromCurrency by remember { mutableStateOf("JPY") }
    var toCurrency by remember { mutableStateOf("EUR") }
    var rates by remember { mutableStateOf<Map<String, Double>>(emptyMap()) }
    var rateDate by remember { mutableStateOf("Aucun taux enregistré") }
    var status by remember { mutableStateOf("Prêt") }
    var showCamera by remember { mutableStateOf(false) }
    var cameraPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }

    fun refreshIfDue(force: Boolean = false) {
        scope.launch {
            status = "Vérification des taux…"
            val result = RateStore.getRates(context, force)
            rates = result.rates
            rateDate = result.dateLabel
            status = result.message
        }
    }

    LaunchedEffect(Unit) { refreshIfDue() }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                status = "Lecture de la photo…"
                try {
                    val image = InputImage.fromFilePath(context, uri)
                    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    recognizer.process(image)
                        .addOnSuccessListener { result ->
                            val found = findAmount(result.text)
                            if (found != null) amountText = found
                            status = if (found != null) "Montant détecté : $found — vérifie-le avant conversion." else "Aucun montant évident détecté. Saisis-le manuellement."
                            recognizer.close()
                        }
                        .addOnFailureListener {
                            status = "Lecture impossible. Essaie une image plus nette."
                            recognizer.close()
                        }
                } catch (_: Exception) {
                    status = "Impossible d'ouvrir cette image."
                }
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        cameraPermission = it
        if (it) showCamera = true else status = "Autorise l'accès caméra dans les paramètres Android."
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("ChangeSnap") },
                    actions = {
                        TextButton(onClick = { refreshIfDue() }) { Text("Taux") }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Convertisseur de devises", style = MaterialTheme.typography.headlineSmall)
                Text("Photo ou caméra pour lire un prix, puis vérifie le montant et la devise.")
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' } },
                    label = { Text("Montant") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    CurrencyMenu("De", fromCurrency, { fromCurrency = it }, Modifier.weight(1f))
                    CurrencyMenu("Vers", toCurrency, { toCurrency = it }, Modifier.weight(1f))
                }

                val amount = amountText.replace(',', '.').toDoubleOrNull()
                val converted = if (amount != null && fromCurrency in rates && toCurrency in rates) {
                    amount / rates.getValue(fromCurrency) * rates.getValue(toCurrency)
                } else null
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Résultat estimé", style = MaterialTheme.typography.titleMedium)
                        Text(
                            converted?.let { "${formatNumber(it)} $toCurrency" } ?: "Taux indisponibles",
                            style = MaterialTheme.typography.headlineMedium
                        )
                        Text("Référence des taux : $rateDate", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Button(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text("Choisir une photo / image")
                }
                OutlinedButton(
                    onClick = {
                        if (cameraPermission) showCamera = !showCamera
                        else permissionLauncher.launch(Manifest.permission.CAMERA)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (showCamera) "Fermer la caméra" else "Scanner avec la caméra en direct") }

                if (showCamera && cameraPermission) {
                    CameraScanner(
                        onTextFound = { text ->
                            val found = findAmount(text)
                            if (found != null) {
                                amountText = found
                                status = "Montant détecté : $found — vérifie-le avant conversion."
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(280.dp)
                    )
                    Text("Pointe la caméra vers le prix. Le montant détecté est rempli automatiquement ; vérifie-le.")
                }

                OutlinedButton(onClick = { refreshIfDue() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Vérifier les taux (au maximum 1 fois par jour)")
                }
                Text(status, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Les taux sont des taux de référence journaliers, pas des cours de change en temps réel. Les conversions fonctionnent avec le dernier cache enregistré, même hors ligne.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun CurrencyMenu(label: String, selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            currencies.forEach { currency ->
                DropdownMenuItem(text = { Text(currency) }, onClick = {
                    onSelect(currency)
                    expanded = false
                })
            }
        }
    }
}

@Composable
private fun CameraScanner(onTextFound: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val recognizer = remember { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                try {
                    val provider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                    val analyzerExecutor = Executors.newSingleThreadExecutor()
                    val analysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                    var lastReadAt = 0L
                    analysis.setAnalyzer(analyzerExecutor) { proxy ->
                        val now = System.currentTimeMillis()
                        if (now - lastReadAt < 900) {
                            proxy.close()
                        } else {
                            lastReadAt = now
                            val mediaImage = proxy.image
                            if (mediaImage == null) proxy.close()
                            else {
                                val input = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
                                recognizer.process(input)
                                    .addOnSuccessListener { result -> if (result.text.isNotBlank()) onTextFound(result.text) }
                                    .addOnCompleteListener { proxy.close() }
                            }
                        }
                    }
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                } catch (_: Exception) { }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        }
    )
}

private data class RateResult(val rates: Map<String, Double>, val dateLabel: String, val message: String)

private object RateStore {
    private const val PREFS = "changesnap_rates"
    private const val KEY_RATES = "rates_json"
    private const val KEY_DATE = "rates_date"
    private const val KEY_FETCH_DAY = "last_fetch_day"

    suspend fun getRates(context: Context, force: Boolean = false): RateResult = withContext(Dispatchers.IO) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val cached = parseRates(prefs.getString(KEY_RATES, null))
        val lastFetchDay = prefs.getString(KEY_FETCH_DAY, null)
        if (!force && lastFetchDay == today) {
            val message = if (cached.isNotEmpty()) {
                "Taux déjà vérifiés aujourd'hui : aucune nouvelle requête."
            } else {
                "Tentative déjà effectuée aujourd'hui sans succès. Réessaie demain ; aucun taux n'est encore en cache."
            }
            return@withContext RateResult(cached, prefs.getString(KEY_DATE, "Cache local") ?: "Cache local", message)
        }
        // Record the attempt before the request so repeated taps cannot retry several times today,
        // even if the phone is offline or the rate service fails.
        prefs.edit().putString(KEY_FETCH_DAY, today).apply()
        try {
            // Frankfurter publishes daily reference rates; no API key is needed.
            val connection = (URL("https://api.frankfurter.dev/v1/latest?base=EUR").openConnection() as HttpURLConnection)
            connection.connectTimeout = 7000
            connection.readTimeout = 7000
            connection.requestMethod = "GET"
            connection.setRequestProperty("Accept", "application/json")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val json = JSONObject(body)
            val fresh = mutableMapOf("EUR" to 1.0)
            val ratesJson = json.getJSONObject("rates")
            val keys = ratesJson.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                fresh[key] = ratesJson.getDouble(key)
            }
            if (fresh.isNotEmpty()) {
                prefs.edit()
                    .putString(KEY_RATES, JSONObject(fresh as Map<*, *>).toString())
                    .putString(KEY_DATE, json.optString("date", today))
                    .putString(KEY_FETCH_DAY, today)
                    .apply()
                RateResult(fresh, json.optString("date", today), "Taux journaliers mis à jour.")
            } else {
                RateResult(cached, prefs.getString(KEY_DATE, "Cache local") ?: "Cache local", "Réponse de taux vide ; cache conservé.")
            }
        } catch (_: Exception) {
            RateResult(cached, prefs.getString(KEY_DATE, "Cache local") ?: "Cache local", if (cached.isNotEmpty()) "Hors ligne ou service indisponible : dernier cache conservé." else "Impossible de récupérer les taux. Connecte-toi puis réessaie.")
        }
    }

    private fun parseRates(raw: String?): Map<String, Double> {
        if (raw.isNullOrBlank()) return emptyMap()
        return try {
            val obj = JSONObject(raw)
            val out = mutableMapOf<String, Double>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                out[key] = obj.getDouble(key)
            }
            out
        } catch (_: Exception) { emptyMap() }
    }
}

private fun findAmount(text: String): String? {
    // Remove common currency symbols/codes, then find plausible price-like numbers.
    val cleaned = text.replace(Regex("(?i)JPY|EUR|USD|GBP|¥|￥|€|\\$|£|円"), " ")
    val matches = Regex("(?<![A-Za-z])\\d{1,3}(?:[,. ]\\d{3})+(?:[,.]\\d{1,2})?|\\d+(?:[,.]\\d{1,2})?").findAll(cleaned).toList()
    val candidate = matches.lastOrNull()?.value ?: return null
    val normalized = when {
        candidate.contains(",") && candidate.contains(".") ->
            if (candidate.lastIndexOf(',') > candidate.lastIndexOf('.')) candidate.replace(".", "").replace(",", ".") else candidate.replace(",", "")
        candidate.count { it == ',' } > 1 -> candidate.replace(",", "")
        candidate.count { it == '.' } > 1 -> candidate.replace(".", "")
        candidate.contains(",") -> {
            val parts = candidate.split(",")
            if (parts.lastOrNull()?.length == 3) candidate.replace(",", "") else candidate.replace(",", ".")
        }
        candidate.contains(".") -> {
            val parts = candidate.split(".")
            if (parts.lastOrNull()?.length == 3) candidate.replace(".", "") else candidate
        }
        else -> candidate
    }
    return normalized.toDoubleOrNull()?.takeIf { it > 0 }?.let { formatNumber(it) }
}

private fun formatNumber(value: Double): String = String.format(Locale.US, "%,.2f", value).trimEnd('0').trimEnd('.')
